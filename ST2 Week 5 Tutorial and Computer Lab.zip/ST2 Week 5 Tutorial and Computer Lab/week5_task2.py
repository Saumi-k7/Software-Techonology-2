# MINI-PROJECT: MERGE SORT (A real-world sorting algorithm)
# Merge sort is a sorting algorithm which is
# efficient enough to be commonly used in practice.
# The idea of merge sort is to split a list up
# into smaller and smaller pieces until all that
# remains are single element lists. Since single
# element lists are necessarily sorted, this is
# our 'base case', and we can then start to
# reassemble the list in sorted order.
import random
import timeit

def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        left_split = array[:len(array) // 2]  # Integer division
        right_split = array[len(array) // 2:]

        left = merge_sort(left_split)
        right = merge_sort(right_split)

        return merge(left, right)


def merge(left, right):
    merged = []

    left_pointer = 0
    right_pointer = 0

    merging = True

    while merging:

        left_element = left[left_pointer]
        right_element = right[right_pointer]

        if left_element < right_element:
            merged.append(left_element)
            left_pointer += 1
        elif right_element < left_element:
            merged.append(right_element)
            right_pointer += 1
        elif right_element == left_element:  # Equal items
            merged.append(right_element)
            merged.append(left_element)
            left_pointer += 1
            right_pointer += 1

        if left_pointer >= len(left):  # Reached end of left list
            merged.extend(right[right_pointer:])
            merging = False
        elif right_pointer >= len(right):  # Reached end of right list
            merged.extend(left[left_pointer:])
            merging = False

    return merged


# ALGORITHMS FOR TESTING MERGE SORT AGAINST INSERTION SORT FOR BENCHMARKING

# INSERTION SORT
def insertion_sort(arr):
    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr


# Testing MERGE SORT with INSERTION SORT

# Generate a large random list
large_random_list = [random.randint(1, 1000) for _ in range(100)]

# Compare times
print("Benchmark the algorithm efficiency")
print("-" * 55)
print(f"\n{'Size':>8}  {'Insertion (s)':>15}  {'Merge (s)':>12}")
print("-" * 58)
sizes = [10,100,1000,5000,10000]

for size in sizes:
    data = [random.randint(1, 1000) for _ in range(size)]
    t_ins = timeit.timeit(lambda: insertion_sort(data[:]), number=10)
    t_mer = timeit.timeit(lambda: merge_sort(data[:]),     number=10)
    print(f"{size:>8}  {t_ins:>15.6f}  {t_mer:>12.6f}")
print("-" * 55)
print("Merge Sort")

# Small list
l1 = [1,2,3,5,6,7,8,9,10,25]
print(f"\nSmall list:")
print(f"  Before: {l1}")
print(f"  After Sorted:  {merge_sort(l1)}")

# Single element
l2 = [1]
print(f"\nSingle element list:")
print(f"  Before: {l2}")
print(f"  After Sorted:  {merge_sort(l2)}")



# Medium list
l4 = [random.randint(1, 1000) for _ in range(100)]
print(f"\nMedium random list")
print(f"  Before: {l4[:10]} ...")
print(f"  After Sorted:  {merge_sort(l4)[:10]} ...")

# Large list
l5 = [random.randint(1, 1000) for _ in range(10000)]
print(f"\nLarge random list")
print(f"  Before: {l5[:10]} ...")
print(f"  After Sorted:  {merge_sort(l5)[:10]} ...")



# Test Insertion Sort with same data sizes

print("\n" + "-" * 55)
print("Insertion Sort")


# Small list
l1 = [1,2,3,5,6,7,8,9,10,25]
print(f"\nSmall list")
print(f"  Before: {l1}")
print(f"  After Sorted:  {insertion_sort(l1)}")

# Single element
l2 = [1]
print(f"\nSingle element list:")
print(f"  Before: {l2}")
print(f"  After Sorted:  {insertion_sort(l2)}")

# Medium list
l4 = [random.randint(1, 1000) for _ in range(100)]
print(f"\nMedium random list")
print(f"  Before: {l4[:10]} ...")
print(f"  After Sorted:  {insertion_sort(l4)[:10]} ...")

# Large list
l5 = [random.randint(1, 1000) for _ in range(10000)]
print(f"\nLarge random list")
print(f"  Before: {l5[:10]} ...")
print(f"  After Sorted:  {insertion_sort(l5)[:10]} ...")







