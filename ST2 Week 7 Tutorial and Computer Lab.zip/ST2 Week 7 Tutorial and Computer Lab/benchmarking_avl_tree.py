import time
import random
import string
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt



class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root


class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right
        y.right = z
        z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left
        y.left = z
        z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node
        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)
        return node

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)
        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)


def benchmark(n=1000, search_fraction=0.5, delete_count=100, verbose=True):
    names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

    bst = BST()
    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert_time = time.time() - start

    search_names = random.sample(names, int(n * search_fraction)) + ['notfoundname'] * int(n * (1 - search_fraction))
    start = time.time()
    found_bst = sum(1 for name in search_names if bst.search(bst.root, name))
    bst_search_time = time.time() - start

    delete_names = random.sample(names, delete_count)
    start = time.time()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete_time = time.time() - start

    avl = AVLTree()
    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert_time = time.time() - start

    start = time.time()
    found_avl = sum(1 for name in search_names if avl.search(avl.root, name))
    avl_search_time = time.time() - start

    start = time.time()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete_time = time.time() - start

    results = {
        'Insertions': (bst_insert_time, avl_insert_time),
        'Searches': (bst_search_time, avl_search_time),
        'Deletions': (bst_delete_time, avl_delete_time),
        'Found In Search': (found_bst, found_avl)
    }
    return results


def collect_multisize_data(sizes, num_search=100, num_delete=50):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}

    for n in sizes:
        names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        bst = BST()
        start = time.time()
        for i in range(n):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            bst.search(bst.root, name)
        bst_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_times['delete'].append(time.time() - start)

        avl = AVLTree()
        start = time.time()
        for i in range(n):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            avl.search(avl.root, name)
        avl_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_times['delete'].append(time.time() - start)

    return bst_times, avl_times



def show_plot(sizes, bst_times, avl_times):
    BST_COLOR = '#1f77b4'
    AVL_COLOR = '#ff7f0e'

    fig, axes = plt.subplots(3, 1, figsize=(10, 8))

    configs = [
        ('insert', 'Insertion Time vs Input Size', 'BST Insert', 'AVL Insert'),
        ('search', 'Search Time vs Input Size',    'BST Search', 'AVL Search'),
        ('delete', 'Deletion Time vs Input Size',  'BST Delete', 'AVL Delete'),
    ]

    for ax, (op, title, bst_label, avl_label) in zip(axes, configs):
        ax.plot(sizes, bst_times[op], '-', color=BST_COLOR,
                label=bst_label, linewidth=1.8, markersize=4)
        ax.plot(sizes, avl_times[op], '-', color=AVL_COLOR,
                label=avl_label, linewidth=1.8, markersize=4)
        ax.set_title(title, fontsize=11)
        ax.set_ylabel('Time (seconds)', fontsize=9)
        ax.legend(fontsize=9, framealpha=0.9)
        ax.grid(True, color='#cccccc', linewidth=0.7, linestyle='-', alpha=0.8)
        ax.set_facecolor('#ffffff')
        ax.tick_params(labelsize=9)

    axes[-1].set_xlabel('Number of Nodes', fontsize=10)
    plt.tight_layout()
    plt.show()


class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL Benchmark")
        master.resizable(True, True)

        tk.Label(master, text="BST vs AVL Tree Benchmark",
                 font=("Arial", 13, "bold")).pack(pady=8)

        # ── Buttons ──
        btn_frame = tk.Frame(master)
        btn_frame.pack(pady=4)

        tk.Button(btn_frame,
                  text="Run Benchmark",
                  command=self.run_benchmark,
                  bg="#4a90d9", fg="white",
                  width=24, relief="flat", pady=5).grid(row=0, column=0, padx=8)

        tk.Button(btn_frame,
                  text="Plot Multi-size  (100 → 10000)",
                  command=self.run_multi,
                  bg="#4caf50", fg="white",
                  width=28, relief="flat", pady=5).grid(row=0, column=1, padx=8)

        self.status_var = tk.StringVar(value="Ready.")
        tk.Label(master, textvariable=self.status_var, fg="#555").pack()

        self.result_text = tk.Text(master, height=12, width=64,
                                   font=("Courier", 10))
        self.result_text.pack(pady=6, padx=10)

        tk.Label(master, text="Results Table:", anchor="w").pack(padx=12, anchor="w")
        cols = ("Operation", "BST Time (s)", "AVL Time (s)",)
        self.treeview = ttk.Treeview(master, columns=cols, show='headings', height=4)
        for col in cols:
            self.treeview.heading(col, text=col)
            self.treeview.column(col, width=148, anchor="center")
        self.treeview.pack(pady=(0, 12), padx=10)

    def run_benchmark(self):
        self.status_var.set("Running... please wait.")
        self.master.update()

        results = benchmark(verbose=False)
        bi, ai  = results['Insertions']
        bs, as_ = results['Searches']
        bd, ad  = results['Deletions']
        fb, fa  = results['Found In Search']

        summary = (
            f"Benchmark Results  (N = 1000)\n"
            f"{'─'*50}\n"
            f"  Insertion  BST: {bi:.6f}s    AVL: {ai:.6f}s\n"
            f"  Search     BST: {bs:.6f}s    AVL: {as_:.6f}s\n"
            f"  Deletion   BST: {bd:.6f}s    AVL: {ad:.6f}s\n"
            f"{'─'*50}\n"
            f"  Contacts found: BST={fb}/1000   AVL={fa}/1000\n\n"

        )
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, summary)

        for row in self.treeview.get_children():
            self.treeview.delete(row)
        for op in ['Insertions', 'Searches', 'Deletions']:
            b, a = results[op]

            self.treeview.insert('', tk.END,
                                 values=(op, f"{b:.6f}", f"{a:.6f}",))
        self.status_var.set("Done!")

    def run_multi(self):
        self.status_var.set("Collecting data for 8 sizes (100 → 10000)... please wait.")
        self.master.update()

        sizes = [100, 200, 400, 800, 1600, 3200, 6400, 10000]
        bst_times, avl_times = collect_multisize_data(sizes)

        lines = [
            "Multi-size Benchmark Results\n",
            f"{'─'*58}\n",
            f"{'Size':>7}  {'BST Ins':>10}  {'AVL Ins':>10}"
            f"  {'BST Srch':>10}  {'AVL Srch':>10}\n",
            f"{'─'*58}\n",
        ]
        for i, n in enumerate(sizes):
            lines.append(
                f"{n:>7}  "
                f"{bst_times['insert'][i]:>10.6f}  "
                f"{avl_times['insert'][i]:>10.6f}  "
                f"{bst_times['search'][i]:>10.6f}  "
                f"{avl_times['search'][i]:>10.6f}\n"
            )
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, ''.join(lines))

        self.status_var.set("Data collected! Plot window opening now...")
        self.master.update()

        show_plot(sizes, bst_times, avl_times)
        self.status_var.set("Plot closed. Ready.")

if __name__ == "__main__":
    root = tk.Tk()
    app = BenchmarkApp(root)
    root.mainloop()