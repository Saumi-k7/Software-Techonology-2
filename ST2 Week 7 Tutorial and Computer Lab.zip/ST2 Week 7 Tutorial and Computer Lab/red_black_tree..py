import time
import random
import string
import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1

class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        if not node:
            return 0
        return node.height

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right
        y.right = z
        z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left
        y.left = z
        z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node
        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)
        return node

    def min_value_node(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                temp = root.right
                root = None
                return temp
            elif root.right is None:
                temp = root.left
                root = None
                return temp
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        if root is None:
            return root
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)
        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)

    def inorder(self, root, res=None):
        if res is None:
            res = []
        if root:
            self.inorder(root.left, res)
            res.append((root.name, root.phone))
            self.inorder(root.right, res)
        return res

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root


# Red-Black Tree Rules:
#   1. Every node is RED or BLACK
#   2. Root is always BLACK
#   3. No two RED nodes in a row (red node cannot have red child)
#   4. Every path from node to NIL leaf has same number of BLACK nodes
#   Violations are fixed using recoloring and rotations.


RED   = "RED"
BLACK = "BLACK"


class RBNode:
    def __init__(self, name, phone):
        self.name   = name
        self.phone  = phone
        self.color  = RED       # new nodes start RED
        self.left   = None
        self.right  = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL       = RBNode(None, None)
        self.NIL.color = BLACK
        self.root      = self.NIL

    def _left_rotate(self, x):
        y        = x.right
        x.right  = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left  = y
        else:
            x.parent.right = y
        y.left   = x
        x.parent = y

    def _right_rotate(self, x):
        y        = x.left
        x.left   = y.right
        if y.right != self.NIL:
            y.right.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left  = y
        y.right  = x
        x.parent = y

    # Insert
    def insert(self, name, phone):
        # Step 1: standard BST insert
        node        = RBNode(name, phone)
        node.left   = self.NIL
        node.right  = self.NIL
        node.parent = None

        parent  = None
        current = self.root
        while current != self.NIL:
            parent = current
            if node.name < current.name:
                current = current.left
            elif node.name > current.name:
                current = current.right
            else:
                current.phone = phone   # update if exists
                return

        node.parent = parent
        if parent is None:
            self.root = node
        elif node.name < parent.name:
            parent.left  = node
        else:
            parent.right = node
        node.color = RED
        self._fix_insert(node)

    def _fix_insert(self, z):
        """
        Fix violations after insert.
        Cases:
          Case 1 – Uncle is RED   → recolor parent, uncle, grandparent
          Case 2 – Uncle is BLACK, triangle → rotate parent
          Case 3 – Uncle is BLACK, line     → rotate grandparent
        """
        while z.parent and z.parent.color == RED:
            if z.parent == z.parent.parent.left:
                y = z.parent.parent.right
                if y.color == RED:
                    z.parent.color        = BLACK
                    y.color               = BLACK
                    z.parent.parent.color = RED
                    z = z.parent.parent
                else:
                    if z == z.parent.right:
                        z = z.parent
                        self._left_rotate(z)
                    z.parent.color        = BLACK
                    z.parent.parent.color = RED
                    self._right_rotate(z.parent.parent)
            else:
                y = z.parent.parent.left
                if y.color == RED:
                    z.parent.color        = BLACK
                    y.color               = BLACK
                    z.parent.parent.color = RED
                    z = z.parent.parent
                else:
                    if z == z.parent.left:
                        z = z.parent
                        self._right_rotate(z)
                    z.parent.color        = BLACK
                    z.parent.parent.color = RED
                    self._left_rotate(z.parent.parent)
        self.root.color = BLACK

    # Delete
    def _transplant(self, u, v):
        if u.parent is None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left  = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def _minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def delete(self, name):
        z = self.search(self.root, name)
        if z is None:
            return
        y            = z
        y_orig_color = y.color
        if z.left == self.NIL:
            x = z.right
            self._transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self._transplant(z, z.left)
        else:
            y            = self._minimum(z.right)
            y_orig_color = y.color
            x            = y.right
            if y.parent == z:
                x.parent = y
            else:
                self._transplant(y, y.right)
                y.right        = z.right
                y.right.parent = y
            self._transplant(z, y)
            y.left         = z.left
            y.left.parent  = y
            y.color        = z.color
        if y_orig_color == BLACK:
            self._fix_delete(x)

    def _fix_delete(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                w = x.parent.right
                if w.color == RED:
                    w.color        = BLACK
                    x.parent.color = RED
                    self._left_rotate(x.parent)
                    w = x.parent.right
                if w.left.color == BLACK and w.right.color == BLACK:
                    w.color = RED
                    x       = x.parent
                else:
                    if w.right.color == BLACK:
                        w.left.color  = BLACK
                        w.color       = RED
                        self._right_rotate(w)
                        w = x.parent.right
                    w.color        = x.parent.color
                    x.parent.color = BLACK
                    w.right.color  = BLACK
                    self._left_rotate(x.parent)
                    x = self.root
            else:
                w = x.parent.left
                if w.color == RED:
                    w.color        = BLACK
                    x.parent.color = RED
                    self._right_rotate(x.parent)
                    w = x.parent.left
                if w.right.color == BLACK and w.left.color == BLACK:
                    w.color = RED
                    x       = x.parent
                else:
                    if w.left.color == BLACK:
                        w.right.color = BLACK
                        w.color       = RED
                        self._left_rotate(w)
                        w = x.parent.left
                    w.color        = x.parent.color
                    x.parent.color = BLACK
                    w.left.color   = BLACK
                    self._right_rotate(x.parent)
                    x = self.root
        x.color = BLACK

    # Search
    def search(self, node, name):
        if node == self.NIL or node is None:
            return None
        if name == node.name:
            return node
        if name < node.name:
            return self.search(node.left,  name)
        return self.search(node.right, name)

    #Inorder
    def inorder(self, node, res=None):
        if res is None:
            res = []
        if node != self.NIL and node is not None:
            self.inorder(node.left,  res)
            res.append((node.name, node.phone, node.color))
            self.inorder(node.right, res)
        return res


def benchmark(n=1000, search_fraction=0.5, delete_count=100):
    names  = [''.join(random.choices(string.ascii_lowercase, k=10))
              for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10))
              for _ in range(n)]
    search_names = (random.sample(names, int(n * search_fraction)) +
                    ['notfoundname'] * int(n * (1 - search_fraction)))
    delete_names = random.sample(names, delete_count)

    # BST
    bst = BST()
    t = time.time()
    for i in range(n): bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_ins = time.time() - t
    t = time.time()
    found_bst = sum(1 for nm in search_names if bst.search(bst.root, nm))
    bst_srch = time.time() - t
    t = time.time()
    for nm in delete_names: bst.root = bst.delete(bst.root, nm)
    bst_del = time.time() - t

    # AVL
    avl = AVLTree()
    t = time.time()
    for i in range(n): avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_ins = time.time() - t
    t = time.time()
    found_avl = sum(1 for nm in search_names if avl.search(avl.root, nm))
    avl_srch = time.time() - t
    t = time.time()
    for nm in delete_names: avl.root = avl.delete(avl.root, nm)
    avl_del = time.time() - t

    # RBT
    rbt = RedBlackTree()
    t = time.time()
    for i in range(n): rbt.insert(names[i], phones[i])
    rbt_ins = time.time() - t
    t = time.time()
    found_rbt = sum(1 for nm in search_names if rbt.search(rbt.root, nm))
    rbt_srch = time.time() - t
    t = time.time()
    for nm in delete_names: rbt.delete(nm)
    rbt_del = time.time() - t

    return {
        'Insertions':      (bst_ins,  avl_ins,  rbt_ins),
        'Searches':        (bst_srch, avl_srch, rbt_srch),
        'Deletions':       (bst_del,  avl_del,  rbt_del),
        'Found In Search': (found_bst, found_avl, found_rbt),
    }


def collect_multisize_data(sizes, num_search=100, num_delete=50):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}
    rbt_times = {'insert': [], 'search': [], 'delete': []}  # NEW

    for n in sizes:
        names  = [''.join(random.choices(string.ascii_lowercase, k=8))
                  for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10))
                  for _ in range(n)]
        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        # BST
        bst = BST()
        t = time.time()
        for i in range(n): bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.time() - t)
        t = time.time()
        for nm in search_names: bst.search(bst.root, nm)
        bst_times['search'].append(time.time() - t)
        t = time.time()
        for nm in delete_names: bst.root = bst.delete(bst.root, nm)
        bst_times['delete'].append(time.time() - t)

        # AVL
        avl = AVLTree()
        t = time.time()
        for i in range(n): avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.time() - t)
        t = time.time()
        for nm in search_names: avl.search(avl.root, nm)
        avl_times['search'].append(time.time() - t)
        t = time.time()
        for nm in delete_names: avl.root = avl.delete(avl.root, nm)
        avl_times['delete'].append(time.time() - t)

        # RBT (NEW)
        rbt = RedBlackTree()
        t = time.time()
        for i in range(n): rbt.insert(names[i], phones[i])
        rbt_times['insert'].append(time.time() - t)
        t = time.time()
        for nm in search_names: rbt.search(rbt.root, nm)
        rbt_times['search'].append(time.time() - t)
        t = time.time()
        for nm in delete_names: rbt.delete(nm)
        rbt_times['delete'].append(time.time() - t)

    return bst_times, avl_times, rbt_times


def show_plot(sizes, bst_times, avl_times, rbt_times):
    BST_COLOR = '#1f77b4'
    AVL_COLOR = '#ff7f0e'
    RBT_COLOR = '#d62728'
    fig, axes = plt.subplots(3, 1, figsize=(10, 8))


    configs = [
        ('insert', 'Insertion Time vs Input Size'),
        ('search', 'Search Time vs Input Size'),
        ('delete', 'Deletion Time vs Input Size'),
    ]

    for ax, (op, title) in zip(axes, configs):
        ax.plot(sizes, bst_times[op], '-', color=BST_COLOR,
                label='BST',        linewidth=1.8)
        ax.plot(sizes, avl_times[op], '-', color=AVL_COLOR,
                label='AVL',        linewidth=1.8)
        ax.plot(sizes, rbt_times[op], '-', color=RBT_COLOR,
                label='Red-Black',  linewidth=1.8)
        ax.set_title(title, fontsize=11)
        ax.set_ylabel('Time (seconds)', fontsize=9)
        ax.legend(fontsize=9, framealpha=0.9)
        ax.grid(True, color='#cccccc', linewidth=0.7, alpha=0.8)
        ax.set_facecolor('#ffffff')
        ax.tick_params(labelsize=9)

    axes[-1].set_xlabel('Number of Nodes', fontsize=10)
    plt.tight_layout()
    plt.show()

class RBTContactApp:
    def __init__(self, master):
        self.rbt    = RedBlackTree()
        self.master = master
        master.title("Task 5 – Red-Black Tree")
        master.resizable(True, True)

        tk.Label(master,
                 text="Red-Black Tree",
                 font=("Arial", 13, "bold")).pack(pady=6)

        #Input fields
        inp = tk.Frame(master)
        inp.pack(pady=4)
        tk.Label(inp, text="Name:").grid(row=0, column=0, padx=5,
                                         pady=3, sticky="e")
        self.name_entry = tk.Entry(inp, width=22)
        self.name_entry.grid(row=0, column=1, padx=5)
        tk.Label(inp, text="Phone:").grid(row=1, column=0, padx=5,
                                          pady=3, sticky="e")
        self.phone_entry = tk.Entry(inp, width=22)
        self.phone_entry.grid(row=1, column=1, padx=5)

        #Contact buttons
        cb = tk.Frame(master)
        cb.pack(pady=2)
        for col, (lbl, cmd) in enumerate([
            ("Insert",   self.insert_contact),
            ("Search",   self.search_contact),
            ("Delete",   self.delete_contact),
            ("Show All", self.show_all),
        ]):
            tk.Button(cb, text=lbl, command=cmd,
                      width=12, bg="#b71c1c", fg="white",
                      relief="flat", pady=4).grid(
                          row=0, column=col, padx=4)

        # Benchmark buttons
        bb = tk.Frame(master)
        bb.pack(pady=2)
        tk.Button(bb,
                  text="Run Benchmark",
                  command=self.run_benchmark,
                  bg="#4a90d9", fg="white",
                  width=24, relief="flat", pady=5).grid(
                      row=0, column=0, padx=8)
        tk.Button(bb,
                  text="Plot Multi-size  (100 → 10000)",
                  command=self.run_multi,
                  bg="#4caf50", fg="white",
                  width=28, relief="flat", pady=5).grid(
                      row=0, column=1, padx=8)

        # Status bar
        self.status_var = tk.StringVar(value="Ready.")
        tk.Label(master, textvariable=self.status_var,
                 fg="#555").pack()

        #Output text
        self.output_text = tk.Text(master, height=11, width=66,
                                   font=("Courier", 10))
        self.output_text.pack(pady=6, padx=10)

        #Benchmark table
        tk.Label(master, text="Benchmark Results Table:",
                 anchor="w").pack(padx=12, anchor="w")
        cols = ("Operation", "BST (s)", "AVL (s)", "RBT (s)",)
        self.tv = ttk.Treeview(master, columns=cols,
                               show='headings', height=4)
        for col in cols:
            self.tv.heading(col, text=col)
            self.tv.column(col, width=128, anchor="center")
        self.tv.pack(pady=(0, 4), padx=10)

        #Canvas
        tk.Label(master,
                 text="RBT Visualisation  "
                      "(RED node = red circle, BLACK node = dark circle):",
                 anchor="w").pack(padx=12, anchor="w")
        self.canvas = tk.Canvas(master, width=820, height=340,
                                bg="white", highlightthickness=1,
                                highlightbackground="#ccc")
        self.canvas.pack(pady=(0, 10), padx=10)


    #Contact handlers
    def insert_contact(self):
        name  = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error",
                                   "Please enter both Name and Phone.")
            return
        self.rbt.insert(name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated: {name}")
        self._clear()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error",
                                   "Please enter a name to search.")
            return
        node = self.rbt.search(self.rbt.root, name)
        self.output_text.delete(1.0, tk.END)
        if node:
            self.output_text.insert(
                tk.END,
                f"Found Contact:\n"
                f"  Name  : {node.name}\n"
                f"  Phone : {node.phone}\n"
                f"  Color : {node.color}\n")
        else:
            self.output_text.insert(
                tk.END, f"Contact '{name}' not found.\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error",
                                   "Please enter a name to delete.")
            return
        self.rbt.delete(name)
        messagebox.showinfo("Success",
                            f"Deleted contact (if existed): {name}")
        self._clear()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.rbt.inorder(self.rbt.root)
        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
            return
        root_color = (self.rbt.root.color
                      if self.rbt.root != self.rbt.NIL else "N/A")
        self.output_text.insert(
            tk.END,
            f"Root: {self.rbt.root.name}  [{root_color}]\n"
            f"{'-'*50}\n")
        for name, phone, color in contacts:
            dot = "[R]" if color == RED else "[B]"
            self.output_text.insert(
                tk.END,
                f"  {dot}  {name:20s}  Phone: {phone}\n")

    def _clear(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    #Canvas drawing
    def draw_tree(self):
        self.canvas.delete("all")
        if self.rbt.root == self.rbt.NIL:
            self.canvas.create_text(410, 170,
                text="(empty tree)", fill="gray",
                font=("Arial", 12))
            return
        w = self.canvas.winfo_width() or 820
        self._draw_node(self.rbt.root, w // 2, 28, w // 4, 65, 22)

    def _draw_node(self, node, x, y, x_off, gap=65, radius=22):
        if node == self.rbt.NIL or node is None:
            return
        if node.left != self.rbt.NIL:
            lx, ly = x - x_off, y + gap
            self.canvas.create_line(x, y + radius, lx, ly - radius,
                                    fill="#888", width=1.5)
            self._draw_node(node.left,  lx, ly,
                            max(x_off // 2, 20), gap, radius)
        if node.right != self.rbt.NIL:
            rx, ry = x + x_off, y + gap
            self.canvas.create_line(x, y + radius, rx, ry - radius,
                                    fill="#888", width=1.5)
            self._draw_node(node.right, rx, ry,
                            max(x_off // 2, 20), gap, radius)

        # RED nodes → red circle, BLACK nodes → dark circle
        fill    = "#c62828" if node.color == RED else "#263238"
        outline = "#ff8a80" if node.color == RED else "#607d8b"
        self.canvas.create_oval(x - radius, y - radius,
                                x + radius, y + radius,
                                fill=fill, outline=outline, width=2)
        label = (node.name if len(node.name) <= 8
                 else node.name[:7] + "…")
        self.canvas.create_text(x, y, text=label,
                                fill="white",
                                font=("Arial", 8, "bold"))

    #Benchmark handlers
    def run_benchmark(self):
        self.status_var.set("Running N=1000 benchmark...")
        self.master.update()

        results = benchmark(n=1000)
        bi, ai, ri  = results['Insertions']
        bs, as_, rs = results['Searches']
        bd, ad, rd  = results['Deletions']
        fb, fa, fr  = results['Found In Search']

        summary = (
            f"Benchmark Results  (N = 1000)\n"
            f"{'─'*56}\n"
            f"  {'Op':<10} {'BST':>10}s   {'AVL':>10}s   {'RBT':>10}s\n"
            f"  {'─'*52}\n"
            f"  {'Insert':<10} {bi:>10.6f}   {ai:>10.6f}   {ri:>10.6f}\n"
            f"  {'Search':<10} {bs:>10.6f}   {as_:>10.6f}   {rs:>10.6f}\n"
            f"  {'Delete':<10} {bd:>10.6f}   {ad:>10.6f}   {rd:>10.6f}\n"
            f"{'─'*56}\n"
            f"  Found: BST={fb}  AVL={fa}  RBT={fr}  (out of 1000)\n\n"
            f"  Key insight:\n"
            f"  * RBT insert faster than AVL (fewer rotations)\n"
            f"  * All three search at O(log n)\n"
            f"  * BST fastest for delete on random data but\n"
            f"    degrades to O(n) on sorted input\n"
        )
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, summary)

        for row in self.tv.get_children():
            self.tv.delete(row)
        for op, b, a, r in [("Insert", bi, ai, ri),
                             ("Search", bs, as_, rs),
                             ("Delete", bd, ad, rd)]:
            fastest = min([("BST", b), ("AVL", a), ("RBT", r)],
                          key=lambda x: x[1])[0]
            self.tv.insert('', tk.END,
                           values=(op,
                                   f"{b:.6f}",
                                   f"{a:.6f}",
                                   f"{r:.6f}",
                                   fastest + " ✔"))
        self.status_var.set("Done!")

    def run_multi(self):
        self.status_var.set(
            "Collecting data for 8 sizes (100→10000)... please wait.")
        self.master.update()

        sizes = [100, 200, 400, 800, 1600, 3200, 6400, 10000]
        bst_times, avl_times, rbt_times = collect_multisize_data(sizes)

        lines = [
            "Multi-size Benchmark  (BST vs AVL vs Red-Black)\n",
            f"{'─'*60}\n",
            f"{'Size':>6}  {'BST Ins':>9}  {'AVL Ins':>9}  "
            f"{'RBT Ins':>9}  {'BST Srch':>9}  {'RBT Srch':>9}\n",
            f"{'─'*60}\n",
        ]
        for i, n in enumerate(sizes):
            lines.append(
                f"{n:>6}  "
                f"{bst_times['insert'][i]:>9.5f}  "
                f"{avl_times['insert'][i]:>9.5f}  "
                f"{rbt_times['insert'][i]:>9.5f}  "
                f"{bst_times['search'][i]:>9.5f}  "
                f"{rbt_times['search'][i]:>9.5f}\n"
            )
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, ''.join(lines))
        self.status_var.set("Data collected! Opening plot...")
        self.master.update()

        show_plot(sizes, bst_times, avl_times, rbt_times)
        self.status_var.set("Plot closed. Ready.")


#Entry point
if __name__ == "__main__":
    # Console output
    print("=" * 60)
    print("  Task 5 – Red-Black")
    print("=" * 60)
    r = benchmark(n=1000)
    bi, ai, ri  = r['Insertions']
    bs, as_, rs = r['Searches']
    bd, ad, rd  = r['Deletions']
    fb, fa, fr  = r['Found In Search']
    print(f"\n  {'Operation':<10} {'BST':>12}s  {'AVL':>12}s  {'RBT':>12}s")
    print(f"  {'─'*54}")
    print(f"  {'Insert':<10} {bi:>12.6f}  {ai:>12.6f}  {ri:>12.6f}")
    print(f"  {'Search':<10} {bs:>12.6f}  {as_:>12.6f}  {rs:>12.6f}")
    print(f"  {'Delete':<10} {bd:>12.6f}  {ad:>12.6f}  {rd:>12.6f}")
    print(f"\n  Found: BST={fb}  AVL={fa}  RBT={fr}  /1000\n")

    root = tk.Tk()
    app  = RBTContactApp(root)
    root.mainloop()