# === extended_graph_visualizer.py ===
# Task 8 – Extended Graph Visualizer
# Fixes:
#   1. run_cycle_detection() now works for undirected graphs.
#   2. Buttons that don't apply to the current graph type show a
#      helpful message instead of silently doing nothing.
#   3. Added a "Show Graph Info" label so you can see at a glance
#      whether the loaded graph is directed or undirected.

from graph import Graph
import tkinter as tk
import math
import time
import threading


class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Extended Graph Visualizer")
        self.geometry("650x700")
        self.graph = graph

        # ── Canvas ──────────────────────────────────────────────────
        self.canvas = tk.Canvas(self, width=600, height=490, bg="white")
        self.canvas.pack(pady=6)

        # ── Graph-type info label ────────────────────────────────────
        graph_type = "Directed" if self.graph.directed else "Undirected"
        weighted   = " | Weighted" if self.graph.weighted else ""
        type_label = tk.Label(self, text=f"Graph type: {graph_type}{weighted}",
                              font=("Arial", 10, "italic"), fg="#555")
        type_label.pack()

        # ── Control buttons ──────────────────────────────────────────
        control_frame = tk.Frame(self)
        control_frame.pack(pady=4)

        btn_style = dict(padx=6, pady=4)

        tk.Button(control_frame, text="Run BFS",
                  command=lambda: self.run_traversal("bfs")).pack(side=tk.LEFT, **btn_style)

        tk.Button(control_frame, text="Run DFS",
                  command=lambda: self.run_traversal("dfs")).pack(side=tk.LEFT, **btn_style)

        tk.Button(control_frame, text="Detect Undirected Cycle",
                  command=self.run_cycle_detection).pack(side=tk.LEFT, **btn_style)

        tk.Button(control_frame, text="Detect Directed Cycle",
                  command=self.run_directed_cycle_detection).pack(side=tk.LEFT, **btn_style)

        tk.Button(control_frame, text="Reset Colors",
                  command=self.reset_colors).pack(side=tk.LEFT, **btn_style)

        # ── Status label ─────────────────────────────────────────────
        self.info_label = tk.Label(self, text="", font=("Arial", 11), wraplength=580)
        self.info_label.pack(pady=6)

        # ── Internal state ───────────────────────────────────────────
        self.vertex_positions = {}
        self.vertex_circles   = {}   # vertex  -> canvas oval id
        self.edge_lines        = {}   # (v,nbr) -> canvas line id
        self.node_radius = 22
        self.spacing     = 180
        self.center      = (300, 245)

        self.draw_graph()

    # ────────────────────────────────────────────────────────────────
    # Drawing
    # ────────────────────────────────────────────────────────────────
    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions.clear()
        self.vertex_circles.clear()
        self.edge_lines.clear()

        vertices = list(self.graph.graph.keys())
        n = len(vertices)
        if n == 0:
            return

        angle_gap = 360 / n
        cx, cy = self.center
        r = self.node_radius

        # Place vertices in a circle
        for i, v in enumerate(vertices):
            angle = i * angle_gap
            x = cx + self.spacing * math.cos(math.radians(angle))
            y = cy + self.spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)
            oid = self.canvas.create_oval(x - r, y - r, x + r, y + r,
                                          fill="lightblue", outline="black", width=2)
            self.vertex_circles[v] = oid
            self.canvas.create_text(x, y, text=v, font=("Arial", 12, "bold"))

        # Draw edges
        for v in vertices:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]
                dx, dy = x2 - x1, y2 - y1
                dist = math.sqrt(dx * dx + dy * dy)
                if dist == 0:
                    continue
                ox, oy = dx / dist * r, dy / dist * r
                start = (x1 + ox, y1 + oy)
                end   = (x2 - ox, y2 - oy)

                arrow = tk.LAST if self.graph.directed else None
                lid = self.canvas.create_line(start[0], start[1],
                                              end[0],   end[1],
                                              arrow=arrow, width=2)
                self.edge_lines[(v, nbr)] = lid

                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), "")
                    mid_x = (start[0] + end[0]) / 2
                    mid_y = (start[1] + end[1]) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w),
                                            fill="red", font=("Arial", 10, "italic"))

    # ────────────────────────────────────────────────────────────────
    # Helpers
    # ────────────────────────────────────────────────────────────────
    def reset_colors(self):
        for oid in self.vertex_circles.values():
            self.canvas.itemconfig(oid, fill="lightblue")
        for lid in self.edge_lines.values():
            self.canvas.itemconfig(lid, fill="black", width=2)
        self.info_label.config(text="")

    def highlight_vertex(self, vertex, color):
        oid = self.vertex_circles.get(vertex)
        if oid:
            self.canvas.itemconfig(oid, fill=color)
            self.update()

    def highlight_edge(self, v1, v2, color):
        lid = self.edge_lines.get((v1, v2))
        if lid:
            self.canvas.itemconfig(lid, fill=color, width=3)
            self.update()

    # ────────────────────────────────────────────────────────────────
    # BFS / DFS traversal (animated)
    # ────────────────────────────────────────────────────────────────
    def run_traversal(self, method):
        def worker():
            self.reset_colors()
            visited = set()

            start_vertex = ("A" if "A" in self.graph.graph
                            else next(iter(self.graph.graph), None))
            if not start_vertex:
                self.info_label.config(text="Graph is empty.")
                return

            if method == "bfs":
                queue = [start_vertex]
                seen  = {start_vertex}
                self.info_label.config(text="Running BFS…")
                while queue:
                    vertex = queue.pop(0)
                    if vertex not in visited:
                        visited.add(vertex)
                        self.highlight_vertex(vertex, "orange")
                        self.info_label.config(text=f"BFS visiting: {vertex}")
                        time.sleep(0.7)
                        for nbr in self.graph.graph[vertex]:
                            if nbr not in seen:
                                seen.add(nbr)
                                queue.append(nbr)
                                self.highlight_edge(vertex, nbr, "green")
                                time.sleep(0.3)
                self.info_label.config(text="BFS complete.")

            elif method == "dfs":
                stack = [start_vertex]
                self.info_label.config(text="Running DFS…")
                while stack:
                    vertex = stack.pop()
                    if vertex not in visited:
                        visited.add(vertex)
                        self.highlight_vertex(vertex, "purple")
                        self.info_label.config(text=f"DFS visiting: {vertex}")
                        time.sleep(0.7)
                        for nbr in reversed(self.graph.graph[vertex]):
                            if nbr not in visited:
                                stack.append(nbr)
                                self.highlight_edge(vertex, nbr, "blue")
                                time.sleep(0.3)
                self.info_label.config(text="DFS complete.")

        threading.Thread(target=worker, daemon=True).start()

    # ────────────────────────────────────────────────────────────────
    # Task 8 FIX: Undirected cycle detection (animated)
    # ────────────────────────────────────────────────────────────────
    def run_cycle_detection(self):
        """Detect cycles in an UNDIRECTED graph with animation."""
        self.reset_colors()

        # Guard: only valid for undirected graphs
        if self.graph.directed:
            self.info_label.config(
                text="Undirected cycle detection requires an undirected graph. "
                     "Use 'Detect Directed Cycle' for directed graphs.")
            return

        self.info_label.config(text="Detecting cycles in undirected graph…")

        def worker():
            visited   = set()
            has_cycle = False

            def cycle_dfs(current, parent):
                visited.add(current)
                self.highlight_vertex(current, "yellow")
                self.update()
                time.sleep(0.5)

                for nbr in self.graph.graph[current]:
                    if nbr not in visited:
                        self.highlight_edge(current, nbr, "orange")
                        self.highlight_edge(nbr, current, "orange")   # undirected: both directions
                        self.update()
                        time.sleep(0.4)
                        if cycle_dfs(nbr, current):
                            return True
                    elif nbr != parent:
                        # Back edge found → cycle!
                        self.highlight_edge(current, nbr, "red")
                        self.highlight_edge(nbr, current, "red")
                        self.highlight_vertex(nbr, "red")
                        self.highlight_vertex(current, "red")
                        self.update()
                        time.sleep(0.5)
                        return True
                return False

            for vertex in list(self.graph.graph.keys()):
                if vertex not in visited:
                    if cycle_dfs(vertex, None):
                        has_cycle = True
                        break

            if has_cycle:
                self.info_label.config(text="✔ Cycle detected in the undirected graph!")
            else:
                self.info_label.config(text="✘ No cycles found in the undirected graph.")

        threading.Thread(target=worker, daemon=True).start()

    # ────────────────────────────────────────────────────────────────
    # Directed cycle detection (animated) — unchanged from starter
    # ────────────────────────────────────────────────────────────────
    def run_directed_cycle_detection(self):
        """Detect cycles in a DIRECTED graph using recursion-stack DFS."""
        self.reset_colors()

        if not self.graph.directed:
            self.info_label.config(
                text="Directed cycle detection requires a directed graph. "
                     "Use 'Detect Undirected Cycle' for undirected graphs.")
            return

        self.info_label.config(text="Detecting cycles in directed graph…")

        visited   = set()
        rec_stack = set()
        has_cycle = False

        def dfs(vertex):
            nonlocal has_cycle
            visited.add(vertex)
            rec_stack.add(vertex)
            self.highlight_vertex(vertex, "yellow")
            self.update()
            time.sleep(0.5)

            for nbr in self.graph.graph[vertex]:
                if nbr not in visited:
                    self.highlight_edge(vertex, nbr, "orange")
                    self.update()
                    time.sleep(0.5)
                    if dfs(nbr):
                        self.highlight_edge(vertex, nbr, "red")
                        self.highlight_vertex(nbr, "red")
                        self.highlight_vertex(vertex, "red")
                        self.update()
                        time.sleep(0.5)
                        return True
                elif nbr in rec_stack:
                    # Back edge → cycle in directed graph
                    self.highlight_edge(vertex, nbr, "red")
                    self.highlight_vertex(nbr, "red")
                    self.highlight_vertex(vertex, "red")
                    self.update()
                    time.sleep(0.5)
                    return True

            rec_stack.discard(vertex)
            return False

        for vertex in list(self.graph.graph.keys()):
            if vertex not in visited:
                if dfs(vertex):
                    has_cycle = True
                    break

        if has_cycle:
            self.info_label.config(text="✔ Cycle detected in the directed graph!")
        else:
            self.info_label.config(text="✘ No cycles found in the directed graph.")


# ════════════════════════════════════════════════════════════════════
# Entry point
# Change the graph below to switch between directed / undirected tests
# ════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    import sys

    # ── Test A: Directed graph with a cycle  A→B→C→A, plus C→D ──────
    # Uncomment to test directed cycle detection:
    #
    # g = Graph(directed=True, weighted=False)
    # for v in ['A', 'B', 'C', 'D']:
    #     g.add_vertex(v)
    # g.add_edge('A', 'B')
    # g.add_edge('B', 'C')
    # g.add_edge('C', 'A')   # ← back-edge creates the cycle
    # g.add_edge('C', 'D')

    # ── Test B: Undirected graph with a cycle  A-B-C-A ───────────────
    # Uncomment to test undirected cycle detection:
    #
    g = Graph(directed=False, weighted=False)
    for v in ['A', 'B', 'C', 'D']:
        g.add_vertex(v)
    g.add_edge('A', 'B')
    g.add_edge('B', 'C')
    g.add_edge('C', 'A')   # ← closes the cycle
    g.add_edge('C', 'D')   # ← extra edge (no cycle here)

    app = GraphVisualizer(g)
    app.mainloop()
