class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if self.weighted and (vertex1, vertex2) in self.weights:
                del self.weights[(vertex1, vertex2)]
            if not self.directed:
                self.graph[vertex2].remove(vertex1)
                if self.weighted and (vertex2, vertex1) in self.weights:
                    del self.weights[(vertex2, vertex1)]
        else:
            print("Edge not found.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            # Remove all edges pointing to this vertex
            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)
                    if self.weighted and (v, vertex) in self.weights:
                        del self.weights[(v, vertex)]
            # Remove weights from this vertex
            keys_to_delete = [k for k in self.weights if k[0] == vertex]
            for k in keys_to_delete:
                del self.weights[k]
            del self.graph[vertex]
        else:
            print(f"Vertex '{vertex}' not found.")

    def print_graph(self):
        for vertex in self.graph:
            if self.weighted:
                edges = [(nbr, self.weights.get((vertex, nbr), 0)) for nbr in self.graph[vertex]]
                print(f"  {vertex}: {edges}")
            else:
                print(f"  {vertex}: {self.graph[vertex]}")

    # Task 2: BFS
    def bfs(self, start):
        if start not in self.graph:
            print(f"Vertex '{start}' not found.")
            return []
        visited = []
        queue = [start]
        seen = set([start])
        while queue:
            vertex = queue.pop(0)
            visited.append(vertex)
            for nbr in self.graph[vertex]:
                if nbr not in seen:
                    seen.add(nbr)
                    queue.append(nbr)
        return visited

    # Task 3: DFS
    def dfs(self, start):
        if start not in self.graph:
            print(f"Vertex '{start}' not found.")
            return []
        visited = []
        stack = [start]
        seen = set()
        while stack:
            vertex = stack.pop()
            if vertex not in seen:
                seen.add(vertex)
                visited.append(vertex)
                for nbr in reversed(self.graph[vertex]):
                    if nbr not in seen:
                        stack.append(nbr)
        return visited

    # Task 4: Cycle Detection (undirected)
    def has_undirected_cycle(self):
        visited = set()

        def dfs_cycle(current, parent):
            visited.add(current)
            for nbr in self.graph[current]:
                if nbr not in visited:
                    if dfs_cycle(nbr, current):
                        return True
                elif nbr != parent:
                    return True
            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs_cycle(vertex, None):
                    return True
        return False

    # Task 8: Cycle Detection (directed)
    def has_directed_cycle(self):
        visited = set()
        rec_stack = set()

        def dfs_directed(vertex):
            visited.add(vertex)
            rec_stack.add(vertex)
            for nbr in self.graph[vertex]:
                if nbr not in visited:
                    if dfs_directed(nbr):
                        return True
                elif nbr in rec_stack:
                    return True
            rec_stack.remove(vertex)
            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs_directed(vertex):
                    return True
        return False
