from graph import Graph
import time
import random


def benchmark_graph_operations(num_vertices, num_edges):
    print(f"\n{'─'*50}")
    print(f"Benchmarking: {num_vertices} vertices, {num_edges} edges")
    print(f"{'─'*50}")

    g = Graph()

    # Add vertices
    start_time = time.time()
    for i in range(num_vertices):
        g.add_vertex(str(i))
    vertex_time = time.time()
    print(f"Added {num_vertices} vertices in {vertex_time - start_time:.6f} seconds")

    # Add edges
    edges_added = 0
    for _ in range(num_edges):
        v1 = str(random.randint(0, num_vertices - 1))
        v2 = str(random.randint(0, num_vertices - 1))
        if v1 != v2:
            g.add_edge(v1, v2)
            edges_added += 1
    edge_time = time.time()
    print(f"Added {edges_added} edges in {edge_time - vertex_time:.6f} seconds")

    # BFS from vertex '0'
    if '0' in g.graph:
        bfs_start = time.time()
        g.bfs('0')
        bfs_end = time.time()
        print(f"BFS completed in {bfs_end - bfs_start:.6f} seconds")
    else:
        print("Vertex '0' not found for BFS")

    # DFS from vertex '0'
    if '0' in g.graph:
        dfs_start = time.time()
        g.dfs('0')
        dfs_end = time.time()
        print(f"DFS completed in {dfs_end - dfs_start:.6f} seconds")


if __name__ == "__main__":
    for size in [10, 100, 1000]:
        benchmark_graph_operations(num_vertices=size, num_edges=size * 3)
