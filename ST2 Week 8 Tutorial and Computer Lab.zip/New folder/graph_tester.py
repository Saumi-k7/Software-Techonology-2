from graph import Graph

# ─────────────────────────────────────────────
# TASK 1: Graph Basics – add / remove
# ─────────────────────────────────────────────
print("=" * 40)
print("TASK 1: Graph Basics")
print("=" * 40)

# Basic undirected graph
print("\n-- Undirected graph --")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.print_graph()

# Directed graph
print("\n-- Directed graph --")
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.print_graph()

# Weighted directed graph
print("\n-- Weighted directed graph --")
g = Graph(weighted=True, directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)
g.print_graph()

# Removal tests
print("\n-- Removal test --")
removal_test = Graph()
removal_test.add_vertex('A')
removal_test.add_vertex('B')
removal_test.add_vertex('C')
removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')
print("Initial:")
removal_test.print_graph()

removal_test.remove_edge('A', 'B')
print("After removing edge A-B:")
removal_test.print_graph()

removal_test.remove_vertex('C')
print("After removing vertex C:")
removal_test.print_graph()

# ─────────────────────────────────────────────
# TASK 2: BFS
# ─────────────────────────────────────────────
print("\n" + "=" * 40)
print("TASK 2: Breadth First Search (BFS)")
print("=" * 40)

g = Graph()
for v in ['A', 'B', 'C', 'D', 'E']:
    g.add_vertex(v)
g.add_edge('A', 'B')
g.add_edge('A', 'C')
g.add_edge('B', 'D')
g.add_edge('C', 'E')

print("Graph:")
g.print_graph()
print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

# ─────────────────────────────────────────────
# TASK 3: DFS
# ─────────────────────────────────────────────
print("\n" + "=" * 40)
print("TASK 3: Depth First Search (DFS)")
print("=" * 40)

print("DFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)

# ─────────────────────────────────────────────
# TASK 4: Cycle Detection (undirected)
# ─────────────────────────────────────────────
print("\n" + "=" * 40)
print("TASK 4: Cycle Detection (Undirected)")
print("=" * 40)

# Graph WITH a cycle
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')   # closes the cycle

print("Does cycle_graph have a cycle? ", cycle_graph.has_undirected_cycle())

# Graph WITHOUT a cycle
acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')
print("Does acyclic_graph have a cycle? ", acyclic_graph.has_undirected_cycle())

# ─────────────────────────────────────────────
# TASK 5: Weighted Directed Graph
# ─────────────────────────────────────────────
print("\n" + "=" * 40)
print("TASK 5: Weighted Directed Graph")
print("=" * 40)

wg = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)
wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)
print("Weighted Directed Graph:")
wg.print_graph()
