import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
VERTICAL_GAP = 10
CANVAS_WIDTH = 300
CANVAS_HEIGHT = 500


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class Queue:
    def __init__(self):
        self.head = None  # Front of queue
        self.tail = None  # Rear of queue
        self.size = 0

    def enqueue(self, data):
        new_node = Node(data)
        if self.tail is None:  # Queue is empty
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node
        self.size += 1

    def dequeue(self):
        if self.head is None:  # Queue is empty
            return None
        removed = self.head.data
        self.head = self.head.next
        if self.head is None:  # Queue is now empty
            self.tail = None
        self.size -= 1
        return removed

    def is_empty(self):
        return self.head is None

    def to_list(self):
        arr = []
        current = self.head
        while current:
            arr.append(current.data)
            current = current.next
        return arr


class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = Queue()

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        # Push (Enqueue) controls
        tk.Label(control_frame, text="Push Value:").grid(row=0, column=0)
        self.push_entry = tk.Entry(control_frame, width=10)
        self.push_entry.grid(row=0, column=1)
        push_btn = tk.Button(control_frame, text="Push", command=self.push_value)
        push_btn.grid(row=0, column=2, padx=5)

        # Pop (Dequeue) button
        pop_btn = tk.Button(control_frame, text="Pop", command=self.pop_value)
        pop_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", font=("Arial", 12), fg="blue")
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
                                     fill="lightblue", outline="black", width=2)
        self.canvas.create_text(x + NODE_WIDTH // 2, y + NODE_HEIGHT // 2,
                                text=str(data), font=("Arial", 16))

    def draw_queue(self):
        self.canvas.delete("all")
        nodes = self.queue.to_list()
        x = (CANVAS_WIDTH - NODE_WIDTH) // 2
        y = 20  # Start from top

        for i, val in enumerate(nodes):
            self.draw_node(x, y, val)

            # Label Front at top, Rear at bottom
            if i == 0:
                self.canvas.create_text(x + NODE_WIDTH + 30, y + NODE_HEIGHT // 2,
                                        text="Front", font=("Arial", 12), fill="red")
            if i == len(nodes) - 1:
                self.canvas.create_text(x + NODE_WIDTH + 30, y + NODE_HEIGHT // 2,
                                        text="Rear", font=("Arial", 12), fill="red")

            y += NODE_HEIGHT + VERTICAL_GAP

    def push_value(self):
        try:
            val = int(self.push_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to push.")
            return
        self.queue.enqueue(val)
        self.push_entry.delete(0, tk.END)
        self.status_label.config(text=f"Pushed {val}")
        self.draw_queue()

    def pop_value(self):
        if self.queue.is_empty():
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot pop.")
            return
        val = self.queue.dequeue()
        self.status_label.config(text=f"Popped {val}")
        self.draw_queue()


if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)
    root.mainloop()